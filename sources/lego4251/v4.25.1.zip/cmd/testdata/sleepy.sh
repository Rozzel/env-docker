#!/bin/bash -e

for i in `seq 1 10`
do
  echo $i
  sleep 0.2
done
