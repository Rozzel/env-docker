Test account (with the default endpoint):
- user: `test`
- password: `test`

Noop endpoint:
- https://api.reg.ru/api/regru2/nop
